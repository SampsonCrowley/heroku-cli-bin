// tslint:disable

declare namespace NodeJS {
  interface Global {
    columns?: number;
    testing?: boolean;
  }
}
