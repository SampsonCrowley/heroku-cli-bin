`heroku notifications`
======================

display notifications

* [`heroku notifications`](#heroku-notifications)

## `heroku notifications`

display notifications

```
USAGE
  $ heroku notifications

OPTIONS
  -a, --app=app        app to run command against
  -r, --remote=remote  git remote of app to use
  --all                view all notifications (not just the ones for the current app)
  --json               output in json format
  --read               show notifications already read
```
