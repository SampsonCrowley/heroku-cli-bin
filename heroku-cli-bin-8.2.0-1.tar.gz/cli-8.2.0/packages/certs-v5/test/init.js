'use strict'

const setTZ = require('set-tz')
setTZ('UTC')
