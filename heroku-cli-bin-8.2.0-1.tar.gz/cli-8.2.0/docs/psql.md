`heroku psql`
=============

open a psql shell to the database

* [`heroku psql [DATABASE]`](#heroku-psql-database)

## `heroku psql [DATABASE]`

open a psql shell to the database

```
USAGE
  $ heroku psql [DATABASE]

OPTIONS
  -a, --app=app            (required) app to run command against
  -c, --command=command    SQL command to run
  -f, --file=file          SQL file to run
  -r, --remote=remote      git remote of app to use
  --credential=credential  credential to use
```
