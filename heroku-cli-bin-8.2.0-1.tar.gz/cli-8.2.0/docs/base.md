`heroku base`
=============



* [`heroku base`](#heroku-base)

## `heroku base`

```
USAGE
  $ heroku base
```

_See code: [@heroku-cli/plugin-webhooks](https://github.com/heroku/cli/blob/v7.39.2/src/commands/base.ts)_
