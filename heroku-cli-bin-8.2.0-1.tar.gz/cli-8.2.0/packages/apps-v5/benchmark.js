'use strict'

require('time-require')
require('.')
