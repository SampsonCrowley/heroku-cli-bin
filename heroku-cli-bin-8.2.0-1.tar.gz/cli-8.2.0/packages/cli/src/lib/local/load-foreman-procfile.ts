module.exports = require('foreman/lib/procfile')
