`heroku teams`
==============

manage teams

* [`heroku teams`](#heroku-teams)

## `heroku teams`

list the teams that you are a member of

```
USAGE
  $ heroku teams [--json]

FLAGS
  --json  output in json format

DESCRIPTION
  list the teams that you are a member of

  Use heroku members:* to manage team members.
```
