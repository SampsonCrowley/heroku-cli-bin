**This project is for the Heroku CLI only and issues are reviewed as we are able. If you need more immediate assistence or help with anything not specific to the CLI itself, please use https://help.heroku.com.**

Do you want to request a *feature* or report a *bug*?
-----------------------------------------------------
If bug, first try running `heroku update` and setting `DEBUG=*` to see extra debug information.

What is the current behavior?
-----------------------------
If the current behavior is a bug, please provide the steps to reproduce.

What is the expected behavior?
------------------------------
Please mention your heroku and OS version. Please state if you are behind an HTTP proxy or company firewall as well.
