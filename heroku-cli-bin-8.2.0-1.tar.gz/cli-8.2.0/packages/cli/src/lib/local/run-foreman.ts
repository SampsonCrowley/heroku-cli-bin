require('foreman/nf.js')
