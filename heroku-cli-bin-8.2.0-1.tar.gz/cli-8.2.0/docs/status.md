`heroku status`
===============

display current status of the Heroku platform

* [`heroku status`](#heroku-status)

## `heroku status`

display current status of the Heroku platform

```
USAGE
  $ heroku status [--json]

FLAGS
  --json  output in json format

DESCRIPTION
  display current status of the Heroku platform
```

_See code: [src/commands/status.ts](https://github.com/heroku/cli/blob/v8.2.0/src/commands/status.ts)_
